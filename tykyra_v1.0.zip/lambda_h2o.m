function lambda= lambda_h2o(T)
% D.W. Green, R.H. Perry. Perry's Chemical Engineers' Handbook, 8th
% edition. McGraw-Hill Inc. 2008.
%
% Input: T in K
% Output: mu in W/(m K)

W= 18.02;
C1= 6.2041E-06 ;
C2= 1.3973;
C3= 0;
C4= 0;

lambda= C1*T.^C2 ./ (1 + C3./T + C4./T.^2);

end