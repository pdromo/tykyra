function Cp= Cp_air(T)
% D.W. Green, R.H. Perry. Perry's Chemical Engineers' Handbook, 8th
% edition. McGraw-Hill Inc. 2008.
%
% Input: T in K
% Output: Cp in J/kg/K


W= 28.960; % g/mol ... molar mass
C1= 0.28958e5;
C2= 0.0939e5;
C3= 3.012e3;
C4= 0.0758e5;
C5= 1484;

C= C1 + C2*( (C3./T)./sinh(C3./T) ).^2 + C4*( (C5./T)./cosh(C5./T) ).^2; % J/kmol/K

%  J/(kg K)  =  J/(kmol K)  *  kmol/kg
%                             1/ (g/mol)
Cp= C / W; 


end