close all
clear all
clc

%% Input parameters
% Ambient conditions
air_temperature   = 20+273.15;        % K ...  ambient temperature
relative_humidity = 0.8;              % (-) ... relative humidty

% Droplet Diameter
droplet_sizes=[20]*10^-6;             % m ... initial droplet diameter

% Saliva composition
saliva =  [945 9.00 76 0.5]; % High protein sputum

% SARS-CoV-1 Exponentional decay constant
lambda=0.636/3600;                     %(s^-1)
n_v0 = (10^10).*10^6;                  %(copies/m^3 of liquid)

% Filename
filename='data.mat'

%Load other parameters
parameters

%% Simulation time
t_0= 0;               % s ... initial time
t_end= 600;           % s ... end of simulation time

%% Solve
global D_0 TG RH md_0 s_comp lambda_v

% Set parameters
lambda_v = lambda;
s_comp = saliva;
D_0 = droplet_sizes;
TG = air_temperature;
RH = relative_humidity;

% Initial droplet mass from composition
[md_0 rho_n yw_0 Nv_0]= saliva_mass(D_0,Td_0,saliva,n_v0);

%% Integration
state_0 = [x_0, v_0, Td_0, md_0, yw_0, Nv_0]; % initial state
options= odeset('RelTol', 1e-10, 'AbsTol',mdSMALL) ;

clear tout;
clear stateout;

tic;
%Integration
[tout,stateout] = ode15s(@state_dot, [t_0 , t_end], state_0, options);
procTime_AS= toc;

disp(['  A-S model took ' num2str(procTime_AS), ' s'])

%% Save variables
t =  tout;
X_t =  stateout(1:end, 1);
v_t =  stateout(1:end, 2);
Td_t =  stateout(1:end, 3);
md_t =  stateout(1:end, 4);
yw_t =  stateout(1:end, 5);
Nv_t =  stateout(1:end, 6);
D_t = ((yw_t.*md_t./rhoL_h2o(Td_t))*6/pi + ((1-yw_t).*md_t./rho_n)*6/pi).^(1/3);

save(filename)

%% Plots

subplot(1,3,1)
plot(t, D_t*1e6, 'k-')
xlabel('t (s)')
ylabel('d (\mum)')
pbaspect([1 1 1])
box on
set(gca,'XScale','log')
xlim([1e-2 1e3])
set(gca,'BoxStyle','full','FontName','Times New Roman','FontSize',10);

subplot(1,3,2)
plot(t, X_t, 'k-')
xlabel('t (s)')
ylabel('X (m)')
pbaspect([1 1 1])
box on
set(gca,'BoxStyle','full','FontName','Times New Roman','FontSize',10);

subplot(1,3,3)
plot(t, Nv_t, 'k-')
xlabel('t (s)')
ylabel('Nv(PFU)')
pbaspect([1 1 1])
box on
set(gca,'BoxStyle','full','FontName','Times New Roman','FontSize',10);
