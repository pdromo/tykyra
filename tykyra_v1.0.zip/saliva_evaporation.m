function [Sw D] = saliva_evaporation(yw,md,Td,Tinf,RH,saliva)

%yw = mass fraction of water in the droplet (-)
%md = mass of droplet kg
%Td = droplet temperature [K]
%Tinf = abient temperature [k]
%s_comp = saliva composition [c_water c_salt c_pro c_surf] (kg/m3)

%Sw = pw/psat,w (-)
%dk = droplet droplet diameter (m)

%% Properties 

% Saliva composition
c_water=saliva(1);
c_salt=saliva(2);
c_pro=saliva(3);
c_surf=saliva(4);

% Ideal gas constant  (J/molK)
R= 8.31445985;                        

% Densities of each component (kg/m3)
rho_salt=2160; %NaCl
rho_pro=1362;  %BSA protein
rho_surf=1000; %DPPC surfactant

% Molecular weight of each component (kg/kmol)
M_w=18.02;
M_s=58.4;
M_a=29;
M_pro=66500;
M_surf=734;

% Water density
rho_w = rhoL_h2o(Td);

%% Property of "solid phase"
% Total concentration
c_tot = c_salt + c_pro +c_surf;

% Mass fractions of each component in the solid phase
y_salt=c_salt/c_tot;
y_pro=c_pro/c_tot;
y_surf=c_surf/c_tot;

% Total mass of solid components
m_n = (1-yw)*md;
m_w = yw*md;

% Mass of each component in the droplet
m_salt=y_salt*m_n;
m_pro=y_pro*m_n;
m_surf=y_surf*m_n;

% Volumes
V_n=((m_salt/rho_salt + m_pro/rho_pro +m_surf/rho_surf )); %of solid part
V_w = m_w/rho_w; %of liquid part

% Mean density of solid part
rho_n = m_n/V_n;

% Mean diameter of the solid part
d_n=(6*V_n/pi)^(1/3);

% Aproximated volume assumption, V_d = Vw + Vn
V_d = V_w + V_n;
D = (6*V_d/pi)^(1/3); %droplet diameter

%% Other properties

% Mole fraction
sumA = (m_salt/M_s) + (m_pro/M_pro) + +(m_surf/M_surf) + (m_w/M_w);
xw = (m_w/M_w)/ sumA;

% Surface tension of water
TC = Td-273.15;
sig_w=0.2358*((374.00-TC)/647.15)^1.256*(1-0.625*((374.00-TC)/647.15));

% Surface tension
sig_s = sig_w;

nu_ion = 2;
mf_salt = m_salt/m_w;
mf_pro = m_pro/m_w;
mf_surf = m_surf/m_w;

%% Molalities (of binary solution) (%kg/mol)

molal_s=(m_salt/M_s)*1000/m_w;
molal_p=(m_pro/M_pro)*1000/m_w;
molal_surf=(m_surf/M_surf)*1000/m_w;

%% Osmotic coefficient NaCl, strong electrolyte

 cf = 1000*molal_s*(M_s)/rho_salt; %molal_s here in kmol/kg
 Yf = 77.4*10^-3;
 Aphi = 0.392;
 bpit = 1.2;
 Betaof = 0.018;
 phi_s = 1 + 2*cf*Betaof*Yf - Aphi*(cf^0.5)*(Yf^0.5)/(sqrt(2)+bpit*(cf^0.5)*(Yf^0.5));
 
%% Osmotic coefficient BSA and DPCC Surfactant

%BSA protein
gms=((rho_pro/rho_w)/(molal_p*M_pro/1000) +1)^(1/3);
phi_p = 1 + (gms^-3)*(3-gms^-6)/(1-gms^-3)^2;

% Surfactant
gms_surf=((rho_surf/rho_w)/(molal_surf*M_surf/1000) +1)^(1/3);
phi_surf = 1 + (gms_surf^-3)*(3-gms_surf^-6)/(1-gms_surf^-3)^2;

%% Evaluate Sw

Sw = exp( ((4*(M_w/1000)*sig_s)/(R*Tinf*rho_w*D)) - ((M_w*rho_n*d_n^3)/(rho_w*(D^3-d_n^3)))*(nu_ion*phi_s*mf_salt/M_s + phi_surf*mf_surf/M_surf + phi_p*mf_pro/M_pro));

end






