function CL= CL_h2o(T)
% D.W. Green, R.H. Perry. Perry's Chemical Engineers' Handbook, 8th
% edition. McGraw-Hill Inc. 2008.
%
% Input: T in K
% Output: CL in J/kg/K

W= 18.015;
C1= 276370;
C2= -2090.1 ;
C3= 8.125 ;
C4= -0.014116;
C5= 9.3701E-06;

C= C1 + C2*T + C3*T.^2 + C4*T.^3 + C5*T.^4; % J/kmol/K

%  J/(kg K)  =  J/(kmol K)  *  kmol/kg
%                             1/ (g/mol)
CL= C / W; 


end