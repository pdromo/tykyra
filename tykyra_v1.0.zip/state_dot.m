function state_dot= state_dot_AS_2(t, state)
% ODEs for an evaporating droplet.
% Evap model: Using nomenclature from Miller, Harstad & Bellan (1998).
% Saliva model: Mikhailov et al. (2003)
% Virus decay: van Doremalen et al. (2020)

global D_0 TG RH md_0 s_comp lambda_v

X= state(1);  %vertical position
v= state(2);  %vertical velocity
Td= state(3); %droplet temperature
md= state(4); %total droplet mass
yw= state(5); %water mass fraction in droplet
Nv= state(6); %viral load

parameters

% Initial floor check
if X<=0
        X_dot=0;
        v_dot=0;
        Td_dot=0;
        md_dot=0;
        yw_dot=0;
        Nv_dot=0;
else
  
%% Evaluate droplet composition

md_n = (1-yw)*md; %Mass of solid

%% Effect on evaporation

[Sw D] = saliva_evaporation(yw,md,Td,TG,RH,s_comp);
rhoL = md/((pi/6)*D^3);

%% Saturation pressure and surface concentration
       
%Pure water    
pSat= Psat_h2o(Td);
pw = Sw*pSat; %Vapour pressure at the surface

theta2= W_air / W_h2o;
Xseq= pw/pG; %Molar fraction at the surface
Yseq= Xseq / (Xseq + (1-Xseq)*theta2 ); %Mass fraction at the surface

%% Ambient Humidity

p_h2o = RH*Psat_h2o(TG);
x_h2o = p_h2o/pG;
YG = x_h2o*W_h2o/(x_h2o*W_h2o + (1-x_h2o)*W_air);

%% Reference conditions

% ("1/3 rule")
TR= (2*Td   + 1*TG )/3;
YR= (2*Yseq + 1*YG )/3 ;

%% Gas properties at reference conditions

% Molar weight @ reference conditions
WR= ( YR/W_h2o + (1-YR)/W_air )^(-1);

% Gas properties @ reference conditions
rhoG= pG / (RR/WR *TR);
CpG=  YR*CpV_h2o(TR) + (1-YR)*Cp_air(TR);
muG=  YR*mu_h2o(TR) + (1-YR)*mu_air(TR);
lambdaG= YR*lambda_h2o(TR) + (1-YR)*lambda_air(TR);
DDG=  D_h2o_air(pG,TR);  % diffusivity

%%  Liquid properties

%rhoL= rhoL_h2o(Td);
CL  = CL_h2o(Td);
LV  = LV_h2o(Td);          % J/kg ... latent heat at boiling point

%% Derived quantities

us= abs(v-uG);    % m/s ... slip velocity
theta1= CpG / CL;
taud= rhoL*D^2/(18*muG);      % particle time constant for Stokes flow

%% Non-dimensional numbers

BMeq= (Yseq - YG)/(1 - Yseq);

rhoInf= pG / (RR/W_air *TG);
Red= rhoInf*us*D/muG;
PrG= CpG*muG/lambdaG;
ScG= muG/rhoG/DDG;
DDG= D_h2o_air(pG,TR);
ScG= muG/rhoG/DDG;

% Ranz-Marshall correlation
Nu= 2 + 0.552 * Red^(1/2) * PrG^(1/3);
Sh= 2 + 0.552 * Red^(1/2) * ScG^(1/3);

%% Mass & Temperature 
% Abramzon and Sirignano model

if abs(Yseq-YG) <= 1e-12 || RH==1
    md_dot= 0;
    Td_dot= 0;
    
else
    
    FM= (1+BMeq)^0.7 / BMeq * log(1+BMeq);
    ShStar= 2 + (Sh-2)/FM;
    
    HM = log(1+BMeq);
    
    md_dot= - pi*D*ShStar*DDG*rhoG * HM;
    
    CpV  = CpV_h2o(TR);
    CpBar= YR*CpV_h2o(TR) + (1-YR)*Cp_air(TR);
    LeBar= ScG/PrG;
        
    % Initialise BT
    FM= (1+BMeq)^0.7 / BMeq * log(1+BMeq);
    FT= FM;
    Phi= 1.0;
    NuStar= 2 + (Nu-2)/FT;
    ShStar= 2 + (Sh-2)/FM;
    BTnew= (TG-Td)*(CpV/LV);
    BT= -100;   % dummy value
    
    % BT iteration
    i= 0;
    imax= 5;
    while( abs((BTnew-BT)/BTnew) > 1e-3 & i<=imax)
        BT= BTnew;
        FT= (1+BT)^0.7 / BT * log(1+BT);
        NuStar= 2 + (Nu-2)/FT ;
        Phi= (CpV/CpG) * (ShStar/NuStar) * (1/LeBar);
        
        BTnew= (1 + BMeq)^Phi - 1.0;
        i= i+1;
    end
    BT= BTnew;
   
    f2= -md_dot/(md*BT) * (3*PrG*taud/Nu);
    
    HdT = 0.0;
    
    Td_dot= -md_dot/(md*BT) * CpV / CL*(TG - Td) + (LV/CL)*(md_dot/md);
    
end

%% Water mass fraction

yw_dot = (md_n/(md^2))*md_dot;

%% Motion
        
X_dot= v;
    
%Schiller and Naumann (1933) Drag
if Red>1000
    Cd=0.424;
else
    Cd=(24/Red)*(1+(1/6)*Red^(2/3));
end
    
v_dot= g*(1-rhoG/rhoL) - 3*Cd*rhoG*us*(v-uG)/(4*rhoL*D);
end

%% Viral activity

Nv_dot = -lambda_v*Nv;

%% Model output

state_dot= [X_dot, v_dot, Td_dot, md_dot, yw_dot, Nv_dot]';

end