function mu= mu_air(T)
% D.W. Green, R.H. Perry. Perry's Chemical Engineers' Handbook, 8th
% edition. McGraw-Hill Inc. 2008.
%
% Input: T in K
% Output: mu in Pa*s (= kg/(m s))



W= 28.960;
C1= 1.425E-06;
C2= 0.5039;
C3= 108.3;
C4= 0.0;

mu= (C1* T.^C2) ./ (1 + C3./T + C4./T.^2);

end