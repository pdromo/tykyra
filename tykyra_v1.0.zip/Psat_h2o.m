function Psat= Psat_h2o(T)
% D.W. Green, R.H. Perry. Perry's Chemical Engineers' Handbook, 8th
% edition. McGraw-Hill Inc. 2008.
%
% Input: T in K
% Output: Psat in Pa


C1= 73.649 ;
C2= -7258.2 ;
C3= -7.3037 ;
C4= 4.1653E-06; 
C5= 2 ;

Psat= exp(  C1 + C2./T + C3*log(T) + C4.*T.^C5  );

end