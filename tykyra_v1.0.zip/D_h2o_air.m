function D= D_h2o_air(P,T)
% Properties of Gases and Liquids
%
% Fuller et al.
%
% Input: T in K, P in Pa
% Output: D in m^2/s


% Molar masses
% W_c2h5oh = 46.068;  % g/mol ... molar mass
W_h2o = 18.015;
W_air = 28.960;     % g/mol ... molar mass

MAB= 2* (1/W_air + 1/W_h2o)^(-1);

% Pressure
Pbar= P*1e-5;

% Diffusion volumes
% %             2*C    + 6* H   + 1*O
% sigma_c2h5oh= 2*15.9 + 6*2.31 + 1*6.11;
sigma_h2o= 13.1; 
sigma_air= 19.7; 

% D_AB in cm^2/s
D_AB= (0.00143* T.^1.75) ./ ...
         (Pbar * MAB^(1/2) * (sigma_air^(1/3) + sigma_h2o^(1/3))^2 );

% m^2/s = cm^2/s * 1e-4 m^2/cm^2

D= D_AB * 1e-4;

end