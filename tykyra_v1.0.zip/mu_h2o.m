function mu= mu_h2o(T)
% D.W. Green, R.H. Perry. Perry's Chemical Engineers' Handbook, 8th
% edition. McGraw-Hill Inc. 2008.
%
% Input: T in K
% Output: mu in Pa*s (= kg/(m s))

W= 18.015;
C1= 1.7096E-08;
C2= 1.1146;
C3= 0;
C4= 0;

mu= (C1* T.^C2) ./ (1 + C3./T + C4./T.^2);

end