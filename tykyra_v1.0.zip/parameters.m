%% Simulation parameters
 
mdSMALL= 1e-20;
DSMALL = 1e-14;

%% Initial conditions
x_0 = 1.5;                              % m ... initial droplet position
v_0 = 1e-6;                             % m/s ... initial droplet velocity
Td_0= 273.15+33 ;                       % K ... initial droplet temperature

%% Physical parameters

pG = 1.0*101325;                        % Pa ... ambient pressure
Tb = 373.15;                            % K ... boiling point at pG
uG = 0.0;                               % m/s ... velocity of gas stream
g = -9.81;                              % m/s2 ... gravity

%% Constants

RR= 8.31445985;                         % J/(mol K) ... ideal gas constant

%% Thermodynamical properties

% Water
W_h2o= 18.015e-3;                       % kg/mol ... molar mass
Tc= 647.096 ;                           % K ... critical temperature
pc= 22.064*1e6;                         % Pa ... critical pressure

% Air
W_n2= 28.02*1e-3;
W_air= 28.960*1e-3;                     % kg/mol ... molar mass