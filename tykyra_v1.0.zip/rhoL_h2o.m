function rhoL= rhoL_h2o(T)
% D.W. Green, R.H. Perry. Perry's Chemical Engineers' Handbook, 8th
% edition. McGraw-Hill Inc. 2008.
%
% Input: T in K
% Output: rhoL in kg/m^3

W= 18.015;

tau= 1 - T/647.096;

dens=  17.863 + 58.606*tau.^0.35 - 95.396*tau.^(2/3) + 213.89*tau - 141.26*tau.^(4/3);  % mol/dm^3

%                                kg/mol = g/mol * 0.001
%           kg/dm^3 = mol/dm^3 * kg/mol
% kg/m^3 =  kg/dm^3                                     * 1000 dm^3/m^3
% kg/m^3 =  mol/dm^3 * ( g/mol * 0.001 )  * 1000 dm^3/m^3

rhoL= dens * W;

end