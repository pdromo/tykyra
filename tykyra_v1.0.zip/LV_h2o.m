function LV= LV_c2h5oh(T)
% D.W. Green, R.H. Perry. Perry's Chemical Engineers' Handbook, 8th
% edition. McGraw-Hill Inc. 2008.
%
% Input: T in K ... boiling point
% Output: Latent heat LV in J/kg

W= 18.015 ;
C1= 5.2053e7 ;
C2= 0.3199 ;
C3= -0.212 ;
C4= 0.25795;
C5= 0;

Tc =  647.096 ;  % K ... critical temperature

Tr= T/Tc; 

L = C1* (1-Tr).^(C2 + C3*Tr + C4*Tr.^2 + C5*Tr.^3);   % J/kmol

%                 1/(g/mol)
% J/kg = J/kmol * kmol/kg

LV= L / W;

end