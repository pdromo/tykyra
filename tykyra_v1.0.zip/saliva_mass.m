function [md rho_n yw Nv] = saliva_mass(D,Td,saliva,n_v)

%% Properties 

% Saliva composition
c_water=saliva(1);
c_salt=saliva(2);
c_pro=saliva(3);
c_surf=saliva(4);

%Ideal gas constant  (J/molK)
R= 8.31445985;                        

% Densities of each component (kg/m3)
rho_salt=2160; %NaCl
rho_pro=1362;  %BSA protein
rho_surf=1000; %DPPC surfactant

%Molecular weight of each component (kg/kmol)
M_w=18.02;
M_s=58.4;
M_a=29;
M_pro=66500;
M_surf=734;

%Water density
rho_w = rhoL_h2o(Td);

%% Property of "solid phase"
%Total concentration
c_tot = c_salt + c_pro +c_surf;

% Volumes
V_d = (pi/6)*(D)^(3); %droplet diameter

% Mass of each component in the droplet
m_salt=c_salt*V_d;
m_pro=c_pro*V_d;
m_surf=c_surf*V_d;

% Volumes
V_n=((m_salt/rho_salt + m_pro/rho_pro + m_surf/rho_surf)); %of solid part

V_w = V_d - V_n;
m_w = V_w*rho_w;

m_n = m_salt + m_pro + m_surf;
md = m_n + m_w;

rho_n = m_n/V_n;

yw = m_w/(md);

%% Emitted virus

Nv = V_d*n_v;

end




