function lambda= lambda_air(T)
% D.W. Green, R.H. Perry. Perry's Chemical Engineers' Handbook, 8th
% edition. McGraw-Hill Inc. 2008.
%
% Input: T in K
% Output: mu in W/(m K)


W= 28.96 ;   % g/mol
C1= 0.00031417;
C2= 0.7786 ;
C3= -0.7116;
C4= 2121.7;

lambda= C1*T.^C2 ./ (1 + C3./T + C4./T.^2);

end